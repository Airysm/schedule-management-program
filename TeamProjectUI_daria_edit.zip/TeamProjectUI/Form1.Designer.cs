﻿
namespace TeamProject
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.btn_deleteCategory = new MetroFramework.Controls.MetroButton();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.metroButton_Add = new MetroFramework.Controls.MetroButton();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.flowLayoutPanel_일정 = new System.Windows.Forms.FlowLayoutPanel();
            this.checkedListBox2 = new System.Windows.Forms.CheckedListBox();
            this.newCtgrTxtBox = new MetroFramework.Controls.MetroTextBox();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroStyleExtender1 = new MetroFramework.Components.MetroStyleExtender(this.components);
            this.metroStyleManager1 = new MetroFramework.Components.MetroStyleManager(this.components);
            this.blueDesignRB = new MetroFramework.Controls.MetroRadioButton();
            this.yellowDesignRB = new MetroFramework.Controls.MetroRadioButton();
            this.groupBox3.SuspendLayout();
            this.flowLayoutPanel_일정.SuspendLayout();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(11, 9);
            this.metroButton1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(143, 34);
            this.metroButton1.TabIndex = 6;
            this.metroButton1.Text = "+ 새 목록";
            this.metroButton1.UseSelectable = true;
            this.metroButton1.UseStyleColors = true;
            this.metroButton1.Click += new System.EventHandler(this.MetroButton1_Click);
            // 
            // btn_deleteCategory
            // 
            this.btn_deleteCategory.Location = new System.Drawing.Point(77, 331);
            this.btn_deleteCategory.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_deleteCategory.Name = "btn_deleteCategory";
            this.btn_deleteCategory.Size = new System.Drawing.Size(80, 29);
            this.btn_deleteCategory.TabIndex = 9;
            this.btn_deleteCategory.Text = "목록 삭제";
            this.btn_deleteCategory.UseSelectable = true;
            this.btn_deleteCategory.UseStyleColors = true;
            this.btn_deleteCategory.Click += new System.EventHandler(this.Btn_deleteCategory_Click);
            // 
            // checkedListBox1
            // 
            this.metroStyleExtender1.SetApplyMetroTheme(this.checkedListBox1, true);
            this.checkedListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.checkedListBox1.CheckOnClick = true;
            this.checkedListBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "학업",
            "운동",
            "생활"});
            this.checkedListBox1.Location = new System.Drawing.Point(11, 93);
            this.checkedListBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(142, 220);
            this.checkedListBox1.TabIndex = 7;
            // 
            // monthCalendar1
            // 
            this.metroStyleExtender1.SetApplyMetroTheme(this.monthCalendar1, true);
            this.monthCalendar1.Location = new System.Drawing.Point(200, 86);
            this.monthCalendar1.Margin = new System.Windows.Forms.Padding(10, 11, 10, 11);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 8;
            this.monthCalendar1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateSelected);
            // 
            // groupBox3
            // 
            this.metroStyleExtender1.SetApplyMetroTheme(this.groupBox3, true);
            this.groupBox3.Controls.Add(this.metroButton_Add);
            this.groupBox3.Controls.Add(this.metroTextBox1);
            this.groupBox3.Location = new System.Drawing.Point(3, 313);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Size = new System.Drawing.Size(389, 125);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // metroButton_Add
            // 
            this.metroButton_Add.Location = new System.Drawing.Point(296, 89);
            this.metroButton_Add.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.metroButton_Add.Name = "metroButton_Add";
            this.metroButton_Add.Size = new System.Drawing.Size(86, 29);
            this.metroButton_Add.TabIndex = 1;
            this.metroButton_Add.Text = "Add";
            this.metroButton_Add.UseSelectable = true;
            this.metroButton_Add.UseStyleColors = true;
            this.metroButton_Add.Click += new System.EventHandler(this.metroButton_Add_Click);
            // 
            // metroTextBox1
            // 
            // 
            // 
            // 
            this.metroTextBox1.CustomButton.Image = null;
            this.metroTextBox1.CustomButton.Location = new System.Drawing.Point(317, 1);
            this.metroTextBox1.CustomButton.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.metroTextBox1.CustomButton.Name = "";
            this.metroTextBox1.CustomButton.Size = new System.Drawing.Size(57, 57);
            this.metroTextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.CustomButton.TabIndex = 1;
            this.metroTextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox1.CustomButton.UseSelectable = true;
            this.metroTextBox1.CustomButton.Visible = false;
            this.metroTextBox1.Lines = new string[0];
            this.metroTextBox1.Location = new System.Drawing.Point(7, 25);
            this.metroTextBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.metroTextBox1.MaxLength = 32767;
            this.metroTextBox1.Multiline = true;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.PromptText = "일정 입력";
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.SelectionLength = 0;
            this.metroTextBox1.SelectionStart = 0;
            this.metroTextBox1.ShortcutsEnabled = true;
            this.metroTextBox1.Size = new System.Drawing.Size(375, 59);
            this.metroTextBox1.TabIndex = 0;
            this.metroTextBox1.UseSelectable = true;
            this.metroTextBox1.WaterMark = "일정 입력";
            this.metroTextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // flowLayoutPanel_일정
            // 
            this.metroStyleExtender1.SetApplyMetroTheme(this.flowLayoutPanel_일정, true);
            this.flowLayoutPanel_일정.AutoScroll = true;
            this.flowLayoutPanel_일정.Controls.Add(this.groupBox3);
            this.flowLayoutPanel_일정.FlowDirection = System.Windows.Forms.FlowDirection.BottomUp;
            this.flowLayoutPanel_일정.Location = new System.Drawing.Point(465, 86);
            this.flowLayoutPanel_일정.Margin = new System.Windows.Forms.Padding(11, 12, 11, 12);
            this.flowLayoutPanel_일정.Name = "flowLayoutPanel_일정";
            this.flowLayoutPanel_일정.Size = new System.Drawing.Size(423, 442);
            this.flowLayoutPanel_일정.TabIndex = 2;
            this.flowLayoutPanel_일정.WrapContents = false;
            // 
            // checkedListBox2
            // 
            this.metroStyleExtender1.SetApplyMetroTheme(this.checkedListBox2, true);
            this.checkedListBox2.FormattingEnabled = true;
            this.checkedListBox2.Location = new System.Drawing.Point(200, 304);
            this.checkedListBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkedListBox2.Name = "checkedListBox2";
            this.checkedListBox2.Size = new System.Drawing.Size(250, 224);
            this.checkedListBox2.TabIndex = 2;
            // 
            // newCtgrTxtBox
            // 
            this.newCtgrTxtBox.BackColor = System.Drawing.SystemColors.Window;
            // 
            // 
            // 
            this.newCtgrTxtBox.CustomButton.Image = null;
            this.newCtgrTxtBox.CustomButton.Location = new System.Drawing.Point(121, 1);
            this.newCtgrTxtBox.CustomButton.Name = "";
            this.newCtgrTxtBox.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.newCtgrTxtBox.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.newCtgrTxtBox.CustomButton.TabIndex = 1;
            this.newCtgrTxtBox.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.newCtgrTxtBox.CustomButton.UseSelectable = true;
            this.newCtgrTxtBox.CustomButton.Visible = false;
            this.newCtgrTxtBox.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.newCtgrTxtBox.Lines = new string[0];
            this.newCtgrTxtBox.Location = new System.Drawing.Point(11, 50);
            this.newCtgrTxtBox.MaxLength = 32767;
            this.newCtgrTxtBox.Name = "newCtgrTxtBox";
            this.newCtgrTxtBox.PasswordChar = '\0';
            this.newCtgrTxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.newCtgrTxtBox.SelectedText = "";
            this.newCtgrTxtBox.SelectionLength = 0;
            this.newCtgrTxtBox.SelectionStart = 0;
            this.newCtgrTxtBox.ShortcutsEnabled = true;
            this.newCtgrTxtBox.Size = new System.Drawing.Size(143, 23);
            this.newCtgrTxtBox.TabIndex = 10;
            this.newCtgrTxtBox.UseSelectable = true;
            this.newCtgrTxtBox.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.newCtgrTxtBox.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.newCtgrTxtBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.newCtgrTxtBox_KeyDown);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.metroPanel1.Controls.Add(this.btn_deleteCategory);
            this.metroPanel1.Controls.Add(this.newCtgrTxtBox);
            this.metroPanel1.Controls.Add(this.checkedListBox1);
            this.metroPanel1.Controls.Add(this.metroButton1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(26, 170);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(160, 364);
            this.metroPanel1.TabIndex = 3;
            this.metroPanel1.UseStyleColors = true;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // metroStyleManager1
            // 
            this.metroStyleManager1.Owner = this;
            // 
            // blueDesignRB
            // 
            this.blueDesignRB.AutoSize = true;
            this.blueDesignRB.Checked = true;
            this.blueDesignRB.Location = new System.Drawing.Point(764, 40);
            this.blueDesignRB.Name = "blueDesignRB";
            this.blueDesignRB.Size = new System.Drawing.Size(63, 17);
            this.blueDesignRB.TabIndex = 9;
            this.blueDesignRB.TabStop = true;
            this.blueDesignRB.Text = "파랑색";
            this.blueDesignRB.UseSelectable = true;
            this.blueDesignRB.CheckedChanged += new System.EventHandler(this.designColorChoice);
            // 
            // yellowDesignRB
            // 
            this.yellowDesignRB.AutoSize = true;
            this.yellowDesignRB.Location = new System.Drawing.Point(833, 40);
            this.yellowDesignRB.Name = "yellowDesignRB";
            this.yellowDesignRB.Size = new System.Drawing.Size(63, 17);
            this.yellowDesignRB.TabIndex = 10;
            this.yellowDesignRB.Text = "노랑색";
            this.yellowDesignRB.UseSelectable = true;
            this.yellowDesignRB.CheckedChanged += new System.EventHandler(this.designColorChoice);
            // 
            // Form1
            // 
            this.AcceptButton = this.metroButton_Add;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 562);
            this.Controls.Add(this.yellowDesignRB);
            this.Controls.Add(this.blueDesignRB);
            this.Controls.Add(this.checkedListBox2);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.flowLayoutPanel_일정);
            this.Controls.Add(this.monthCalendar1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Padding = new System.Windows.Forms.Padding(23, 75, 23, 25);
            this.Text = "일정관리앱";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox3.ResumeLayout(false);
            this.flowLayoutPanel_일정.ResumeLayout(false);
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.GroupBox groupBox3;
        private MetroFramework.Controls.MetroButton metroButton_Add;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel_일정;
        private System.Windows.Forms.CheckedListBox checkedListBox2;
        private MetroFramework.Controls.MetroButton btn_deleteCategory;
        private MetroFramework.Controls.MetroTextBox newCtgrTxtBox;
        private MetroFramework.Components.MetroStyleExtender metroStyleExtender1;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Components.MetroStyleManager metroStyleManager1;
        private MetroFramework.Controls.MetroRadioButton yellowDesignRB;
        private MetroFramework.Controls.MetroRadioButton blueDesignRB;
    }
}

