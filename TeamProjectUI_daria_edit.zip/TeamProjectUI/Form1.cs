﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using MetroFramework.Controls;

namespace TeamProject
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        public List<일정Group> groupList = new List<일정Group>();
        public List<schedule> scdList = new List<schedule>();
        public Form1()
        {
            InitializeComponent();
            scdList = DB_fuction.DB_load_All();
            this.StyleManager = metroStyleManager1;
           
        }

        private List<schedule> FindScd(string date)
        {
            List<schedule> scdtempList = scdList.FindAll(x => x.txt_date == date);
            Console.WriteLine(scdtempList.Count);
            return scdtempList;
        }

        private void metroButton_Add_Click(object sender, EventArgs e) // 일정 추가 add 버튼 클릭
        {
            if (!String.IsNullOrWhiteSpace(metroTextBox1.Text)) //tasks 간단하게 유지하기 위해 빈 작업을 수락하지 않음
            {

                일정Group group = new 일정Group();
                GroupBox groupBox = new GroupBox();
                MetroTextBox textBox = new MetroTextBox();
                MetroButton editBtn = new MetroButton();
                MetroButton deleteBtn = new MetroButton();
                MetroLabel numLbl = new MetroLabel();

                group.GroupBox_일정 = groupBox;
                group.TextBox_일정 = textBox;
                group.EditBtn_일정 = editBtn;
                group.DeleteBtn_일정 = deleteBtn;
                group.NumLbl_일정 = numLbl;

                groupBox.Controls.Add(textBox);
                groupBox.Controls.Add(editBtn);
                groupBox.Controls.Add(deleteBtn);
                groupBox.Controls.Add(numLbl);

                groupList.Add(group);


                // groupBox 속성 설정
                groupBox.Size = new Size(340, 100);
                metroStyleExtender1.SetApplyMetroTheme(groupBox, true);

                // button 속성 설정
                editBtn.Size = new Size(75, 23);
                editBtn.Location = new Point(179, 71);
                editBtn.Text = "Edit";
                editBtn.Click += editBtn_Click;
                editBtn.Name += groupList.Count.ToString();
                editBtn.UseStyleColors = true;

                deleteBtn.Size = new Size(75, 23);
                deleteBtn.Location = new Point(259, 71);
                deleteBtn.Text = "Delete";
                deleteBtn.Click += deleteBtn_Click;
                deleteBtn.UseStyleColors = true;

                //label
                numLbl.Size = new Size(15,15);
                numLbl.Anchor=AnchorStyles.Left;
                numLbl.Text = groupList.Count.ToString();
                numLbl.Enabled = true;
                metroStyleExtender1.SetApplyMetroTheme(numLbl, true);


                // textBox 속성 설정
                textBox.ReadOnly = true;
                textBox.Multiline = true;
                textBox.Size = new Size(328, 47);               
                textBox.Location = new Point(6, 20);
                textBox.Text = metroTextBox1.Text;
               
                metroTextBox1.Text = ""; //사용자의 편의를 위해 텍스트를 빈 문자열로 설정
                textBoxAlignment();

                // DB에 저장
                DateTime date = monthCalendar1.SelectionStart;
                string strDate = date.ToString("yyyy-MM-dd");
                schedule scd = new schedule(strDate, textBox.Text,-1);

                scdList.Add(scd);
            }
        }

        private void textBoxAlignment() // 텍스트 박스 정렬
        {
            while(flowLayoutPanel_일정.Controls.Count > 1) // 기존의 텍스트 박스를 전부 지움
            {
                flowLayoutPanel_일정.Controls.RemoveAt(1);
            }

            for (int i = groupList.Count - 1; i >= 0; i--) // textBoxList의 textBox들을 다시 전부 넣어줌
            {
                flowLayoutPanel_일정.Controls.Add(groupList[i].GroupBox_일정);
                groupList[i].GroupBox_일정.Name = "group" + i.ToString();
                groupList[i].DeleteBtn_일정.Name = "btn" + i.ToString();
            }

            for (int i = 0; i < flowLayoutPanel_일정.Controls.Count; i++)
            {
                Console.WriteLine(flowLayoutPanel_일정.Controls[i].Name);
            }
        }

        private void editBtn_Click(object sender, EventArgs e)
        {
            if (metroTextBox1.Text == "")
                return;

            MetroButton edtBtn = sender as MetroButton;

            for (int i = 0; i < groupList.Count; i++)
            {
                if (groupList[i].EditBtn_일정.Name == edtBtn.Name)
                {
                    groupList.ElementAt<일정Group>(i).TextBox_일정.Text = metroTextBox1.Text;
                    break;
                }
            }
            metroTextBox1.Text = "";
        }

        private void deleteBtn_Click(object sender, EventArgs e) 
        {
            MetroButton btn = sender as MetroButton;
            int deleteIndex = -1;
            for (int i = 0; i < groupList.Count; i++)
            {
                if (groupList[i].DeleteBtn_일정.Name == btn.Name)
                {
                    deleteIndex = i;
                    break;
                }
            }

            DateTime date = monthCalendar1.SelectionStart;
            string strDate = date.ToString("yyyy-MM-dd");
            schedule scd = new schedule(strDate, groupList[deleteIndex].TextBox_일정.Text, -1);

            groupList.RemoveAt(deleteIndex);
            textBoxAlignment();

            //update the number of the task
            for (int i = 0; i < groupList.Count; i++)
            {
                groupList[i].NumLbl_일정.Text = (i + 1).ToString();
            }


            DB_fuction.DB_delete(scd);
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e) // 달력 날짜 선택
        {
            DateTime date = monthCalendar1.SelectionStart;
            string strDate = date.ToString("yyyy-MM-dd");

            schedule[] findArr = FindScd(strDate).ToArray();
            List<string> findList = new List<string>();
            for(int i = 0; i < findArr.Length; i++)
            {
                findList.Add(findArr[i].txt_detail);
            }

            string[] strArray = findList.ToArray();

            // 그룹박스들 지우기
            groupList.Clear();
            Console.WriteLine(strDate);
            textBoxAlignment();

            // 해당 날짜의 그룹 박스 추가
            for(int i = 0; i < strArray.Length; i++)
            {
                createGroupBox(strDate, strArray[i],  -1); // Category 제작시 수정 필요
            }
        }

        private void createGroupBox(string date, string detail, int category) // 그룹박스 생성 함수 재사용
        {
            일정Group group = new 일정Group();
            GroupBox groupBox = new GroupBox();
            MetroTextBox textBox = new MetroTextBox();
            MetroButton editBtn = new MetroButton();
            MetroButton deleteBtn = new MetroButton();
            MetroLabel numLbl = new MetroLabel();

            group.GroupBox_일정 = groupBox;
            group.TextBox_일정 = textBox;
            group.EditBtn_일정 = editBtn;
            group.DeleteBtn_일정 = deleteBtn;
            group.NumLbl_일정 = numLbl;

            groupBox.Controls.Add(textBox);
            groupBox.Controls.Add(editBtn);
            groupBox.Controls.Add(deleteBtn);
            groupBox.Controls.Add(numLbl);

            groupList.Add(group);


            // groupBox 속성 설정
            groupBox.Size = new Size(340, 100);
            metroStyleExtender1.SetApplyMetroTheme(groupBox, true);

            // button 속성 설정
            editBtn.Size = new Size(75, 23);
            editBtn.Location = new Point(179, 71);
            editBtn.Text = "Edit";
            editBtn.Click += editBtn_Click;
            editBtn.Name += groupList.Count.ToString();
            editBtn.UseStyleColors = true; //design

            deleteBtn.Size = new Size(75, 23);
            deleteBtn.Location = new Point(259, 71);
            deleteBtn.Text = "Delete";
            deleteBtn.Click += deleteBtn_Click;
            deleteBtn.UseStyleColors = true;

            //label
            numLbl.Size = new Size(15, 15);
            numLbl.Anchor = AnchorStyles.Left;
            numLbl.Text = groupList.Count.ToString();
            numLbl.Enabled = true;
            metroStyleExtender1.SetApplyMetroTheme(numLbl, true);


            // textBox 속성 설정
            textBox.ReadOnly = true;
            textBox.Multiline = true;
            textBox.Size = new Size(328, 47);
            textBox.Location = new Point(6, 20);
            textBox.Text = detail;
           

            metroTextBox1.Text = ""; //사용자의 편의를 위해 텍스트를 빈 문자열로 설정
            textBoxAlignment();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DB_fuction.DB_save_All(scdList);
        }

        private void MetroButton1_Click(object sender, EventArgs e)
        {
            if (newCtgrTxtBox.Text != "")
                checkedListBox1.Items.Add(newCtgrTxtBox.Text);
            newCtgrTxtBox.Text = "";
        }

        private void Btn_deleteCategory_Click(object sender, EventArgs e)
        {
            //delete all the tasks as well?


            while (checkedListBox1.CheckedItems.Count > 0)
            {
                checkedListBox1.Items.RemoveAt(checkedListBox1.CheckedIndices[0]);
            }
        }

        //ctrl+enter = +새목록
        private void newCtgrTxtBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                MetroButton1_Click(sender, e);
            }
        }

        private void designColorChoice(object sender, EventArgs e)
        {
            if (blueDesignRB.Checked == true)
                metroStyleManager1.Style = MetroFramework.MetroColorStyle.Blue;
            else
                metroStyleManager1.Style = MetroFramework.MetroColorStyle.Yellow;
        }
    }
}
